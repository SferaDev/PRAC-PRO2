var searchData=
[
  ['isbookselected',['isBookSelected',['../class_library.html#a04ff0757054c2813e89036cdd3f7f91f',1,'Library']]]
];
