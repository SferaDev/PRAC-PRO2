var searchData=
[
  ['generatefrequencytable',['generateFrequencyTable',['../class_book.html#a8d232eaeb4207707d77bc18e6dd467cd',1,'Book']]],
  ['getauthorname',['getAuthorName',['../class_book.html#a651503f226fbf2c9c050f9527a3b983e',1,'Book']]],
  ['getbook',['getBook',['../class_library.html#a67ccad51c76c3abfb0d46fa533f46e03',1,'Library']]],
  ['getbooklines',['getBookLines',['../class_book.html#a8f241d57fb5525e3008b3f3d6ba81291',1,'Book']]],
  ['getbooktitle',['getBookTitle',['../class_book.html#aae6e165b712f111beb53574cd2f53776',1,'Book']]],
  ['getbookwords',['getBookWords',['../class_book.html#a6f0ccce41fd8db486578e0d325605813',1,'Book']]],
  ['getquote',['getQuote',['../class_library.html#aba57d7dcf92c9da4c3d8a359ceba7e2b',1,'Library']]],
  ['gestor_20de_20textos_20i_20cites_20_7c_20alexis_20rico_20and_20jordi_20romero',['Gestor de textos i cites | Alexis Rico and Jordi Romero',['../index.html',1,'']]]
];
