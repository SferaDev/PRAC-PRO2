var searchData=
[
  ['quote',['Quote',['../class_quote.html#ae160077e513fe6346eeba294a195038b',1,'Quote::Quote()'],['../class_quote.html#a12fee26be3fcdf003691e394f256b2c8',1,'Quote::Quote(string reference, string author, string book)']]]
];
