var searchData=
[
  ['book_5fdelete',['BOOK_DELETE',['../main_8cc.html#a7749b7f479d011a8d3311aa8b5fbb4b5',1,'main.cc']]],
  ['book_5finsert',['BOOK_INSERT',['../main_8cc.html#a2b15fbc1759d69bee062c54b05dc462b',1,'main.cc']]],
  ['book_5freplace_5fword',['BOOK_REPLACE_WORD',['../main_8cc.html#abe8ee09135d5fdb707b7d2a35528f5de',1,'main.cc']]],
  ['book_5fselect',['BOOK_SELECT',['../main_8cc.html#aa9363d09f3d16e41e1a0cf3ec842e975',1,'main.cc']]]
];
