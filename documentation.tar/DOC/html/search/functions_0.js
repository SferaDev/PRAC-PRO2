var searchData=
[
  ['author',['Author',['../class_author.html#a5f7059590a8e823fe0713faf66126b17',1,'Author']]]
];
