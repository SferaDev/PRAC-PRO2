var searchData=
[
  ['findword',['findWord',['../class_book.html#af3ceb5ae5d66adf4d594cac8d29294fc',1,'Book']]]
];
