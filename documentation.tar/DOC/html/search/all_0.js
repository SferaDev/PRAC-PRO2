var searchData=
[
  ['author',['Author',['../class_author.html',1,'Author'],['../class_author.html#a5f7059590a8e823fe0713faf66126b17',1,'Author::Author()']]],
  ['author_2ehh',['Author.hh',['../_author_8hh.html',1,'']]]
];
