var searchData=
[
  ['author',['Author',['../class_author.html',1,'']]]
];
