var searchData=
[
  ['quote_2ehh',['Quote.hh',['../_quote_8hh.html',1,'']]]
];
