var searchData=
[
  ['selectbook',['selectBook',['../class_library.html#a6dd541a183a89a4d35a80834ed9d8d71',1,'Library']]],
  ['setcontent',['setContent',['../class_quote.html#ab3af36f8b5649b115fca7eecbb294a59',1,'Quote']]],
  ['setquotelines',['setQuoteLines',['../class_quote.html#a211e2593b1ef18dc7fd4a5da87384fa1',1,'Quote']]]
];
