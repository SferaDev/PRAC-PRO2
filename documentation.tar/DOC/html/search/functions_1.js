var searchData=
[
  ['book',['Book',['../class_book.html#a2eac9e235a08763158f78533f7a83e1f',1,'Book::Book()'],['../class_book.html#a98dad89c9f945e0d846c81ce7e459fbc',1,'Book::Book(string title, string author)']]]
];
