var searchData=
[
  ['_7eauthor',['~Author',['../class_author.html#ae1d4db056b321487cf7c07a2045d4a2d',1,'Author']]],
  ['_7ebook',['~Book',['../class_book.html#a0ba8eceb34ea1301bc08942e37824767',1,'Book']]],
  ['_7elibrary',['~Library',['../class_library.html#a62120f28a9b50cc5b151d868e42ab936',1,'Library']]],
  ['_7equote',['~Quote',['../class_quote.html#a9b4324f3ee83827f2445177c8301482b',1,'Quote']]]
];
