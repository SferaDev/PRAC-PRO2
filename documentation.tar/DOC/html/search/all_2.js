var searchData=
[
  ['deletebook',['deleteBook',['../class_library.html#a0248e22f1ba1611d3b3c8b7843a6d8b9',1,'Library']]],
  ['deletequote',['deleteQuote',['../class_library.html#a705ee20f1edab1ebf274c9e2cbb4d7a3',1,'Library']]]
];
