var searchData=
[
  ['query_5fauthors',['QUERY_AUTHORS',['../main_8cc.html#a929725ac33851ab44a874af097622fac',1,'main.cc']]],
  ['query_5fbooks_5fall',['QUERY_BOOKS_ALL',['../main_8cc.html#a799ed9876b238eaeca57d69dfeac5712',1,'main.cc']]],
  ['query_5fbooks_5fby_5fauthor',['QUERY_BOOKS_BY_AUTHOR',['../main_8cc.html#aed2de80402367f772f44d697495062b2',1,'main.cc']]],
  ['query_5fcurrent_5fauthor',['QUERY_CURRENT_AUTHOR',['../main_8cc.html#a0daa5c4d40a4733d0c1ebca8839db256',1,'main.cc']]],
  ['query_5fcurrent_5fcontent',['QUERY_CURRENT_CONTENT',['../main_8cc.html#a7463e07bfee66a1652cea25521f25d36',1,'main.cc']]],
  ['query_5fcurrent_5fexpresion',['QUERY_CURRENT_EXPRESION',['../main_8cc.html#a76cc671aba9c92c2fbd71a35dc960fcd',1,'main.cc']]],
  ['query_5fcurrent_5ffrequency',['QUERY_CURRENT_FREQUENCY',['../main_8cc.html#af3ba25cc9f066f3cef24711ef73d6a53',1,'main.cc']]],
  ['query_5fcurrent_5finfo',['QUERY_CURRENT_INFO',['../main_8cc.html#a6d6573826f2957d81a4ff133305ae03c',1,'main.cc']]],
  ['query_5fcurrent_5flines',['QUERY_CURRENT_LINES',['../main_8cc.html#a221416125c781868b41105b22fb97623',1,'main.cc']]],
  ['query_5fcurrent_5fquotes',['QUERY_CURRENT_QUOTES',['../main_8cc.html#a609fa4997165643203e0cb255ca772c6',1,'main.cc']]],
  ['query_5fcurrent_5fwords',['QUERY_CURRENT_WORDS',['../main_8cc.html#aa0dbdd0e7744fe37a953d689ed902adb',1,'main.cc']]],
  ['query_5fquote_5finfo',['QUERY_QUOTE_INFO',['../main_8cc.html#a29278b52bf17327ade47b5ea1cb41899',1,'main.cc']]],
  ['query_5fquotes_5fall',['QUERY_QUOTES_ALL',['../main_8cc.html#ae38061f0fadacde833c2da1403793f06',1,'main.cc']]],
  ['query_5fquotes_5fby_5fauthor',['QUERY_QUOTES_BY_AUTHOR',['../main_8cc.html#abcd8e2524f8645d5d6c12e0062838147',1,'main.cc']]],
  ['quit',['QUIT',['../main_8cc.html#a84f0d54b44b855b01f75732c6fa1bc4b',1,'main.cc']]],
  ['quote',['Quote',['../class_quote.html',1,'Quote'],['../class_quote.html#ae160077e513fe6346eeba294a195038b',1,'Quote::Quote()'],['../class_quote.html#a12fee26be3fcdf003691e394f256b2c8',1,'Quote::Quote(string reference, string author, string book)']]],
  ['quote_2ehh',['Quote.hh',['../_quote_8hh.html',1,'']]],
  ['quote_5fdelete',['QUOTE_DELETE',['../main_8cc.html#ab6b50436074ef3d196d57bb2c1a18346',1,'main.cc']]],
  ['quote_5finsert',['QUOTE_INSERT',['../main_8cc.html#a25732e97c43c06f1a18cc0e4219e84d6',1,'main.cc']]]
];
