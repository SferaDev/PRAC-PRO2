var searchData=
[
  ['quote',['Quote',['../class_quote.html',1,'']]]
];
