var searchData=
[
  ['gestor_20de_20textos_20i_20cites_20_7c_20alexis_20rico_20and_20jordi_20romero',['Gestor de textos i cites | Alexis Rico and Jordi Romero',['../index.html',1,'']]]
];
